AUI().use('aui-base', function(A) {
	A.getBody().append(index++ + 'external file<br/>');
});